#!/bin/bash

vulPath=$1
rhost=$3

msfcli $vulPath rhost=$rhost E <<!END!
exit -y
!END!
