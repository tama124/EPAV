#!/bin/bash

# remove some late update file
rm $HOME/EPAV/update/listPageDownload.txt
rm $HOME/EPAV/update/listPageIDTmp.txt

# declare microsoft link
linkFirst="http://www.microsoft.com/en-us/search/DownloadResults.aspx?q=Security+Update&ftapplicableproducts=Windows&sortby=-availabledate&ftfreeandpaid=Free&First="
linkSecond="http://www.microsoft.com/en-us/download/confirmation.aspx?id="

# declare some variable
declare -a arrayTmp
declare -a arrayTmp2
declare -a arrayID
declare -a arrayLastID
countTmp=0
countTmp2=0
countID=0
countLastID=0
pageNumber=1
	
# get the last update id patches
while read i
do
	arrayLastID+=($i)
	countLastID=`expr $countLastID + 1`
done<$HOME/EPAV/update/listPageID.txt

# get patches id from microsoft
#isHave=`lynx -dump $linkFirst$pageNumber | grep 'id' | awk '/download/{print $2}' | cut -f 2 -d = | awk 'FNR==1'`
lynx -dump $linkFirst$pageNumber | grep 'id' | awk '/download/{print $2}' | cut -f 2 -d =>$HOME/EPAV/update/listPageIDTmp.txt
pageNumber=`expr $pageNumber + 10`

#while [ $isHave"" != "" ]
for ((i=0; i<1; i++))
do
	lynx -dump $linkFirst$pageNumber | grep 'id' | awk '/download/{print $2}' | cut -f 2 -d =>>$HOME/EPAV/update/listPageIDTmp.txt
	pageNumber=`expr $pageNumber + 10`
	#isHave=`lynx -dump $linkFirst$pageNumber | grep 'id' | awk '/download/{print $2}' | cut -f 2 -d = | awk 'FNR==1'`
done

# read listPageIDTmp.txt
while read i
do
	if [[ $i =~ ^[0-9]+$ ]] ; then
		arrayTmp+=($i)
		countTmp=`expr $countTmp + 1`
	fi
done<$HOME/EPAV/update/listPageIDTmp.txt

# remove some dupclicate id patches
arrayTmp2+=(${arrayTmp[0]})
countTmp2=`expr $countTmp2 + 1`
for ((i=1; i<countTmp; i++))
do
	match=0
	for ((j=0; j<countTmp2; j++))
	do
		if [ ${arrayTmp[i]} -eq ${arrayTmp2[j]} ]
		then
			match=`expr $match + 1`
		fi
	done
	if [ $match -eq 0 ]
	then
		arrayTmp2+=(${arrayTmp[i]})
		countTmp2=`expr $countTmp2 + 1`
	fi
done

# remove id patches had been downloaded
for ((i=0; i<countTmp2; i++))
do
	match=0
	for ((j=0; j<countLastID; j++))
	do
		if [ ${arrayTmp2[i]} -eq ${arrayLastID[j]} ]
		then
			match=`expr $match + 1`
		fi
	done
	if [ $match -eq 0 ]
	then
		arrayID+=(${arrayTmp2[i]})
		countID=`expr $countID + 1`
	fi
done

# save patches id to listPageID.txt
for ((i=0; i<countID; i++))
do
	echo ${arrayID[i]}
done>>$HOME/EPAV/update/listPageID.txt

# get patches link download from microsoft
while read ID
do
	echo `lynx -dump "$linkSecond$ID" | grep 'http://download.microsoft.com/download/' | awk '{print $2}' | awk 'FNR==2'`
done<$HOME/EPAV/update/listPageID.txt>$HOME/EPAV/update/listPageDownload.txt

# check directory contain patches download
if [ ! -d $HOME/EPAV/update/downloaded_patches ]; then
	mkdir $HOME/EPAV/update/downloaded_patches
fi

# download the patches
while read url
do
	match=0
	for file in $HOME/EPAV/update/downloaded_patches/*; do
		file=`echo $file| cut -d'/' -f 7`
		if [ $file == ${url##*/} ]
		then
			match=`expr $match + 1`
			break
		fi
	done
	if [ $match -eq 0 ]
	then
		wget $url -O $HOME/EPAV/update/downloaded_patches/${url##*/} #-O -> can save with different name
	fi
done<$HOME/EPAV/update/listPageDownload.txt
